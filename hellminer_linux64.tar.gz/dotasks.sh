#!/bin/bash
screen -d -m bash -c "cd hellminer ; ./mine.sh"
